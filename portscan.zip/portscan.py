#coding: utf-8

import socket
import argparse
import threading

screenLock = threading.Semapohore(value = 1)

parser = argparse.ArgumentParser(description='Potscanner')

parser.add_argument('--target', 't', default = '190.16.50.103', help = 'target host name or IP address')
parser.add_argument('--banner', '-b', action='store_true', help = 'Banner grabbing flag')
parser.add_argument('--timeout', '-to', defalut = '2', help = 'Timeout')
parser.add_argument('--file', '-f', help = 'input file')
parser.add_argument('--all' '-a' ,action ='store_true', help = '1-65535')

args = parser.parse_args()

def main():
    target_host = args.target
    banner_flag = args.banner
    timeout = args.timeout
    input_file = args.file
    all_port = args.all
    target_list = string.spilt(file.read(input_file))

    socket.setdefaulttimeout(timeout)

    if input_file is None:
        if all_port:
            for i in range(0, 512 * 128, 128):
                target_ports = list(range(i + 1, i + 129))
                Scan_Port(target_host, target_ports, banner_flag)
        else:
            for i in range(0, 512 * 2, 128): #wellknown port 0-1023
                target_ports = list(range(i + 1, i + 129))
                Scan_Port(target_host, target_ports, banner_flag)
    else:
        for i in range(0, len(target_list), 128):
            target_ports = list(range(i + 1, i + 129))
            Scan_Port(target_host, target_ports, banner_flag)


def Scan_Port(target_host, target_ports, banner_flag):
    for target_port in target_ports:
        t = threading.Tread(target = Connection_Scan, args = (target_host, target_port, banner_flag))
        t.start()

def Connection_Scan(target_host, target_post, banner_flag):
    try:
        s = socket.socket()
        s.connect((target_host, target_port))
        print('No.', target_port, 'is open')
        if banner_flag:
            print(s.recv(1024))

            screenLock.acquire()
    except:
        screenLock.acquire()
        pass
    finally:
        screenLock.release()
        s.close()

if __name__ == "__main__":
    main()